// APE 1 - Codigo 1: Blink con la API de Arduino (linea base) // Placa: Arduino UNO (ATmega328P @ 16 MHz) - simulacion en Wokwi 
/*
PARTE A Codigo 2
void setup() { 
  pinMode(13, OUTPUT);          
// D13 = PB5 (LED integrado "L") 
} 
void loop() { 
  digitalWrite(13, HIGH); 
  delay(500); 
  digitalWrite(13, LOW); 
  delay(500); 
}*/

// APE 1 - Codigo 2: el mismo Blink, ahora escribiendo registros
// Placa: Arduino UNO (ATmega328P @ 16 MHz) - simulacion en Wokwi
// Regla: no se usa pinMode() ni digitalWrite()
/*void setup() {
DDRB |= (1 << DDB5); // PB5 (D13) como salida; los demás bits no cambian
}
void loop() {
PORTB ^= (1 << PORTB5); // XOR: conmuta solo el bit 5
delay(500); // 500 ms encendido / 500 ms apagado
}
*/


// APE 1 - Parte B2
// Encendido y apagado usando OR y AND
/*
void setup() {
  // PB5 (D13) como salida
  DDRB |= (1 << DDB5);
}

void loop() {
  // ENCENDER LED
  // Coloca el bit 5 de PORTB en 1
  PORTB |= (1 << PORTB5);

  delay(500);

  // APAGAR LED
  // Coloca el bit 5 de PORTB en 0
  PORTB &= ~(1 << PORTB5);

  delay(500);
}*/

// APE 1 - Parte B3
// Conmutación escribiendo directamente en PINB
/*
void setup() {
  // PB5 (D13) como salida
  DDRB |= (1 << DDB5);
}

void loop() {
  // Escribir un 1 en PINB5 conmuta el bit correspondiente de PORTB
  PINB = (1 << PINB5);

  delay(500);
}*/

// APE 1 - Parte B4
// Uso de asignación directa sobre PORTB
/*
void setup() {
  // PB5 (D13) como salida
  DDRB |= (1 << DDB5);
}

void loop() {
  // Coloca PB5 en 1,
  // PERO también coloca todos los demás bits de PORTB en 0
  PORTB = (1 << PORTB5);

  delay(500);

  // Apaga todo PORTB
  PORTB = 0;

  delay(500);
}*/

/*
  APE 1 - Codigo 3: Laboratorio de bits en los puertos B y D

  Arduino UNO - ATmega328P @ 16 MHz

  PB0..PB3 = D8..D11 -> LEDs
  PD2      = D2      -> pulsador a GND
  PB5      = D13     -> LED integrado "L"

  No se usa pinMode(), digitalWrite() ni digitalRead()
*/

const uint8_t MASK_LEDS = 0x0F;   // 00001111 -> PB0..PB3
const uint8_t NUM_MODOS = 3;

// Patrón inicial de cada modo
const uint8_t PATRON_INICIAL[NUM_MODOS] = {
  0b0000,
  0b0001,
  0b0101
};

const unsigned long PERIODO_MS = 300;

uint8_t modo = 0;
uint8_t patron = PATRON_INICIAL[0];

uint8_t btnAnterior = 1;

unsigned long tAnterior = 0;


// Imprime un valor de 8 bits en binario
void imprimirBin8(const char *etiqueta, uint8_t v) {

  Serial.print(etiqueta);

  for (int8_t i = 7; i >= 0; i--) {
    Serial.print((v >> i) & 1);
  }

  Serial.println();
}


// Escribe solamente en PB0..PB3
void escribirLeds(uint8_t valor) {
  PORTB = (PORTB & ~MASK_LEDS) | (valor & MASK_LEDS);
}
/*void escribirLeds(uint8_t valor) {
  PORTB = valor;
}
*/
// Demostración de operaciones binarias
void demoOperaciones() {

  uint8_t a = 0b11001100;
  uint8_t b = 0b10101010;

  imprimirBin8("a = ", a);
  imprimirBin8("b = ", b);

  imprimirBin8("a & b = ", a & b);
  imprimirBin8("a | b = ", a | b);
  imprimirBin8("a ^ b = ", a ^ b);

  imprimirBin8("~a = ", (uint8_t)~a);

  imprimirBin8("a << 1 = ", (uint8_t)(a << 1));
  imprimirBin8("a >> 2 = ", a >> 2);

  Serial.print("~a sin cast, en BIN: ");
  Serial.println(~a, BIN);
}


void setup() {

  // PB0, PB1, PB2, PB3 y PB5 como SALIDAS
  DDRB |= MASK_LEDS | (1 << DDB5);

  // PD2 como ENTRADA
  DDRD &= ~(1 << DDD2);

  // Activar resistencia pull-up interna en D2
  PORTD |= (1 << PORTD2);


  Serial.begin(9600);

  Serial.println(F("APE 1 - Laboratorio de bits"));

  demoOperaciones();

  escribirLeds(patron);
}


void loop() {

  // ==================================================
  // 1. LEER PULSADOR
  // ==================================================

  // Leer únicamente el bit PD2
  uint8_t btn = (PIND >> PIND2) & 1;

  // Con pull-up:
  // 1 = suelto
  // 0 = presionado

  // Detectar cuando pasa de 1 -> 0
  if (btnAnterior == 1 && btn == 0) {

    modo = (modo + 1) % NUM_MODOS;

    patron = PATRON_INICIAL[modo];

    Serial.print(F("Modo: "));
    Serial.println(modo);
  }

  btnAnterior = btn;


  // ==================================================
  // 2. ACTUALIZACIÓN CADA 300 ms
  // ==================================================

  if (millis() - tAnterior >= PERIODO_MS) {

    tAnterior = millis();


    switch (modo) {

      // ----------------------------------------------
      // MODO 0
      // Contador binario
      // ----------------------------------------------
      case 0:

        patron = (patron + 1) & MASK_LEDS;

        break;


      // ----------------------------------------------
      // MODO 1
      // Rotación circular
      // ----------------------------------------------
      case 1:

        patron =
          ((patron << 1) | (patron >> 3))
          & MASK_LEDS;

        break;


      // ----------------------------------------------
      // MODO 2
      // Alternancia mediante XOR
      // ----------------------------------------------
      case 2:

        patron ^= MASK_LEDS;

        break;
    }


    // Mostrar patrón en los LEDs
    escribirLeds(patron);


    // Conmutar LED integrado D13 / PB5
    PINB = (1 << PINB5);


    // Mostrar PORTB en monitor serie
    imprimirBin8("PORTB = ", PORTB);
  }
}